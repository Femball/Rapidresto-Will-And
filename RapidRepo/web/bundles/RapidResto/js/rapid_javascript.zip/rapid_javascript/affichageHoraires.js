document.getElementById("chez_soso").innerHTML = ouvert_fermer('11:00', '14:00', '18:00', '22:00','6', '');
document.getElementById("hom_burger").innerHTML = ouvert_fermer('11:30', '14:00', '18:30', '21:00', '0', '1');
document.getElementById("madame_noy").innerHTML = ouvert_fermer('11:00', '14:00', '18:00', '22:00', '0', '');
document.getElementById("mac_do").innerHTML = ouvert_fermer('11:00', '22:30', '', '', '', '');
document.getElementById("pasta_nostra").innerHTML = ouvert_fermer('11:00', '15:00', '18:00', '22:00', '0', '');
document.getElementById("pablo_pizza").innerHTML = ouvert_fermer('11:00', '14:00', '18:00', '22:30', '1', '2');